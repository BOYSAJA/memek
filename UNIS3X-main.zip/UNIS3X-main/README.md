## Install
```
pkg update && pkg upgrade
pkg install python2
pkg install git
git clone https://github.com/vrhasya/UNIS3X
```

## Run Script
```
cd UNIS3X
ls
python2 UNIS3X.py
```

## Contact
[Facebook](https://www.facebook.com/cindy.adelia.330)
